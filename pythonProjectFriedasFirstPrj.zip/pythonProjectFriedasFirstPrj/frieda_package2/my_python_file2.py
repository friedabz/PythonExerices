from frieda_package.my_python_file import  func2

print("i was here")
print(func2())

# output
#
# C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\python.exe C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\frieda_package2\my_python_file2.py
# 42
#
# Process finished with exit code 0