def func1():
    return  7

def func2():
    return  42