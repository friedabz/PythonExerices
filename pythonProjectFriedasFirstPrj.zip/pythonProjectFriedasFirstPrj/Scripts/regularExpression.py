import  re
line= "my age us 24 and I hsve 3 children and I have 1000 frieand and 89 "
#search numbers the () is for groping
m1=re.search(r'(\d)',line)
m=re.search(r'(\d+)',line) # from the first number to the end of the line  , starts from 0
n=re.search(r'(\d+).',line) # from the first number
o=re.findall(r'(\d+).',line) # from the first number
print('m1',m1)
print('m',m)
print('n',n)
print('o',o)

# C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\python.exe C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\regularExpression.py
# m1 <re.Match object; span=(10, 11), match='2'>
# m <re.Match object; span=(10, 12), match='24'>
# n <re.Match object; span=(10, 13), match='24 '>
# o ['24', '3', '1000', '89']
#
# Process finished with exit code 0


line="the date is 25:07:2004"
m= re.search(r'(\d+):(\d+):(\d+)', line)
m_no_group= re.search(r'\d+:\d+:\d+', line)
print('m_no_group',m_no_group)
print('m.group(1)',m.group(1))
print('m.group(2)',m.group(2))
print('m.group(3)',m.group(3))


pattern=r"Python|Java|C\+\+"
text="I like Python and Java, but not C++"
matches=re.findall(pattern,text,re.IGNORECASE)
print('matches',matches)

new_text=re.sub(pattern,"_python_",text)
print('new_text',new_text)