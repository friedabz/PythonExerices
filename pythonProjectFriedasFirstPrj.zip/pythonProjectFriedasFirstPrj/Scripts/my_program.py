import scope2
import scope as sc  #alias
from  scope2   import func1  # import specific mthod

print(scope2.add_17(3))

app