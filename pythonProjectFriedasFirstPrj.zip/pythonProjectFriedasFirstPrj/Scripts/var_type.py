def my_function_name(a: int , b:  int)->  int:
    """

    :param a: please  use only int
    :param b: please  use only int
    :return: :retruns int type
    """
    c = a + b
    return c


u = my_function_name(4, 6)
print(u)

# output :
# C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\python.exe C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\var_type.py
# 10
# Process finished with exit code 0

# u = my_function_name("a", 6)
# print(u)
# output : error , cant concat two types



u  = my_function_name("a", "6")
print(u)
#output: a6

# use c as optional parameter
def my_function_name(a: int, b: int, c: int =0, d:str = "hello world") -> int:
    """

    :param a: please  use only int
    :param b: please  use only int
    :return: :retruns int type
    """
    if  c is None:
        return a+b
    else:
        g = a + b + c
        print ("d=", d)
        return g

u = my_function_name(4, 6)
print(u)

u = my_function_name(4, 6, 5)
print(u)


# output :
# 10
# 15
#
# Process finished with exit code 0



#use d as defualt :
# use c as optional parameter
def my_function_name(a: int, b: int, c: int =0, d:str = "hello world") -> int:
    """

    :param a: please  use only int
    :param b: please  use only int
    :return: :retruns int type
    """
    if  c is None:
        return a+b
    else:
        g = a + b + c
        print ("d=", d)
        return g

u=my_function_name(1, 4, None,"tamir")
print(u)


def my_function_name(a: int, b: int, c: int =None, d:str = "hello world",*args) -> int:
    """

    :param a: please  use only int
    :param b: please  use only int
    :return: :retruns int type
    """
    sum= 0
    for i  in args:   #notice agrs is tuple
        sum +=i
    print("sum",sum)
    print("sum",sum,type(args))
    if  c is None:
        return a+b+sum
    else:
        g = a + b + c+ sum
        print("g = a + b + c+ sum", )
        print ("d=", d)

        return g



u = my_function_name(1,4,None,1,2,3,4,5,6,7,8,9,10)


def my_function_name(a: int, b: int, c: int =None, d:str = "hello world",*args) -> int:
    sum=0
    print("sum", sum, type(args), "len(args)",len(args))
    for i in args:
        print("i",i,type(i))


u=my_function_name(1,4,None,"tamir", 1,2,3,4,"test",6,[2,3,4,5],8,{"a":3},10)
print(u)
y=my_function_name(1,2)
print(y)


def my_function(a: int,b: int,*args) -> int:
    sum=a+b
    for i in args:
        if type(i) == int:
            sum+=i
    print("sum",sum)

    for j in range(0,len(args)):
        if type(args[j])==int:
            sum += args[j]
        else:
            print(arg[j],f"args in location {j} is not int")
    return sum

u=my_function(1,2,"b",3,"tytyt")
#print("current parameters ","1,2,","b",3,"tytyt",u)
