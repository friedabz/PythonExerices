def append_item_to_list(lst):
    lst.append(4)
    print(f"in function the lst= {lst}")

a=[1,2,3]
append_item_to_list(a)
print("a value outside the function ",a)
#output
#in function the lst = [1, 2, 3, 4]

#example that a value does not changed
a=10
def add_17(z):
        z=z+17
        print("a in function", z)

add_17(a)
print("a=",a)

# output
# a in function 27
# a= 10
#
# Process finished with exit code 0


def func1():
    return 7


def func2(a):
    return a+5