
a=10
def my_func(c : int):
    #a=12
    print("a in function",a)
    return  a+c

f=my_func(12)
print("f",f)
print("a",a)




print("changing gloabl a on my_func")
a=0
def my_func(c : int):
    global  a  # switch to gloabl var
    a+=1
    print("a in function",a)

my_func(12)
my_func(12)
my_func(12)


def my_func2(c : int):
    a=0    #must init a=0 else we get error cause it must init and then add
    a+=1
    print("a in function",a)
print("exec my_func2 ")
my_func2(3)