# my_lst=[1,2,3,4,5,6]
# my_lst2=[1,2,3,4,5,6]
# # my_lst2=["a","t","werwe",7.65,True,[4,6,5,2]]
# # print(my_lst)
# # print(my_lst[2])
# #
# # my_lst[2]="tamir"
# # print(my_lst[2])
# # print(my_lst)
#
# #new_lst=my_lst2+ my_lst
#
# my_lst=  [1,2,3,4,5,6]
# my_lst2= [1,2,3,4,5,6]
# my_lst3= my_lst + my_lst2
# print("my_lst3", my_lst3)
#
# my_lst.append([1,2,3,4])
# my_lst.extend([9,7,6,5])
#
# print(my_lst)
# s=my_lst.pop()
# print(f"s={s} and my_lst={my_lst} ")
# # C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\python.exe C:\Users\Student-24\PycharmProjects\pythonProjectFriedasFirstPrj\venv\Scripts\my_list.py
# # my_lst3 [1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]
# # [1, 2, 3, 4, 5, 6, [1, 2, 3, 4], 9, 7, 6, 5]
# #
# # Process finished with exit code 0
#
# my_lst=  [0,1,"c",3,"f",5,[6,4,5,6]]
# my_lst.append([1,2,3,4])
# print("@~"*20)
#
# a=0
# for i in my_lst:
#     print("a")
#     print(i)
#     print(f"i={i} in index {a}")
#     a+=1
#     print(my_lst[a])
# print("@~"*20)
# print("b")

#
# for char in "abcdefghij":
#     print(char)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#added on 9/7/2023
e=[1,2,3,4,"rtrtr",[1.1,"blb"]]
my_new_list=e.copy()
print("my_new_list")
i=0
for i in range(0,10):
    print(i)


  e=[1,2,3,4]
  i=0
 for i in range(0,len(e),2):
        e[i]=e[i]*1.5
print(e)

