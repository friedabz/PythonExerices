#
# #another example  6/8/20223
# x=[1,2,3,4,5,6,8,9,23,29,56,2,67]
# def bigger_then_7(X):
#     return x>7
#
# my_func = lambda x:x>7
# print(my_func(12))
#
# y=filter(bigger_then_7,x)
# print('y',y)
# y1=filter(lambda x:x> 7, x)
# print('y1',y1)

def my_decorator(func) :
    def inner_function(a,b):
        print(f"I am un decorator a={a}  b={b}")
        res= func(a,b)
        if res> 3 :
            print("res > 3")
    return inner_function

@my_decorator
def my_sum(x,y):
    return x+y

@my_decorator
def my_diff(s,t):
    return s-t

z=my_sum(10,1)
print("z",z)
u=my_diff(9,6)
print("u",u)