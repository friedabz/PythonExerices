
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if
a=13
b=17
if a == b :
    print("a==b")
elif a >= b:
    print("a>=b")
elif b > a:
    print("b >a")
else:
    print("result: a not = b")

a=13
b=13
if a==b : print("vvvv: a equal b ")

if a == b and 3 == 17 :  # two conditions
    print("a==b")


v = None
if v is None:
        print("check result: v is none")
if v is not None:
        print("check result: v is NOT none")

bo = True
if not bo :
    print("bo:  is False")
else: print("bo: is True")
